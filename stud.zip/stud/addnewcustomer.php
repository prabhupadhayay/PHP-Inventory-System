<?php
	require_once 'php_action/db_connect.php';
	if(isset($_POST['add'])){
		$customername=$_POST['customername'];
        $customercontact=$_POST['customercontact'];
        
 
		mysqli_query($connect,"insert into `customer` (customer_name, customer_contact) values ('$customername', '$customercontact')");
	}
?>